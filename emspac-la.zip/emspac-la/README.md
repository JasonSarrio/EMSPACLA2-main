# EMSPAC Louisiana — Website

Marketing / advocacy site for **EMSPAC Louisiana** (Emergency Medical Service Public Advocacy Council), a 501(c)(3) nonprofit advancing a sustainable, accountable, patient-centered EMS system across Louisiana.

**Tagline:** *Stronger Together. Better Future. — For EMS workers. For Louisiana.*

## What's here

```
emspac-la/
├── index.html      ← the entire site (HTML + CSS + JS in one file)
├── assets/
│   ├── emspac-logo.png        ← transparent logo (web-optimized, 480px)
│   └── emspac-logo-hires.png  ← transparent logo (full resolution)
└── README.md
```

`index.html` is fully self-contained — the logo is embedded, and fonts load from Google Fonts. There is **no build step**. Open the file in a browser and it works. The `assets/` logos are provided separately in case you want to reuse the transparent mark elsewhere.

## Deploy on GitHub Pages

1. Create a new repository (e.g. `emspac-la`) and push these files to it.
   ```bash
   git init
   git add .
   git commit -m "Initial EMSPAC Louisiana site"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/emspac-la.git
   git push -u origin main
   ```
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment → Source**, choose **Deploy from a branch**.
4. Select branch **main** and folder **/ (root)**, then **Save**.
5. Your site goes live at `https://YOUR-USERNAME.github.io/emspac-la/` within a minute or two.

### Using a custom domain (e.g. emspacla.org)

1. In **Settings → Pages → Custom domain**, enter `emspacla.org` and save.
2. At your DNS provider, point the domain to GitHub Pages:
   - Apex (`emspacla.org`) → four `A` records: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - `www` → `CNAME` to `YOUR-USERNAME.github.io`
3. Leave **Enforce HTTPS** checked once the certificate is issued.

## Editing the content

Everything is plain HTML in `index.html`. Common edits:

- **Copy / headlines** — search the section you want (e.g. `<!-- HERO -->`, `<!-- ISSUES -->`) and edit the text directly.
- **Links** — the donate, NAEMT, LACAG, legislation PDFs, and social links are standard `<a href="...">` tags.
- **Colors** — all brand colors are CSS variables at the top of the `<style>` block:
  ```css
  --navy-800:#0d2142;  --orange:#e2701e;  --gold:#c9a23f;  --star-blue:#2150d8;
  ```
- **Fonts** — Anton (display), Barlow Condensed (subheads), Barlow (body), Caveat (the brush pull-quote), loaded via the `<link>` in `<head>`.

## Notes

- Responsive down to mobile, keyboard-focusable, and respects `prefers-reduced-motion`.
- The animated EKG/heartbeat line in the hero is inline SVG — no images or libraries.
- Team avatars are styled initials; swap in real photos if you have them.

---

© 2024–2026 EMSPAC Louisiana. 501(c)(3) Nonprofit.
